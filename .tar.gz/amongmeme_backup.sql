-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: amongmeme
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `armors`
--

DROP TABLE IF EXISTS `armors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `armors` (
  `id_armor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `armoR` varchar(16) NOT NULL,
  `defence` int(11) NOT NULL,
  `durability` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `quality` int(11) NOT NULL,
  `rarity` int(11) NOT NULL,
  `toughness` int(11) NOT NULL,
  `id_armor_type` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_armor`),
  KEY `id_armor_type` (`id_armor_type`),
  CONSTRAINT `armors_ibfk_1` FOREIGN KEY (`id_armor_type`) REFERENCES `armors_types` (`id_armor_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `armors`
--

LOCK TABLES `armors` WRITE;
/*!40000 ALTER TABLE `armors` DISABLE KEYS */;
/*!40000 ALTER TABLE `armors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `armors_types`
--

DROP TABLE IF EXISTS `armors_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `armors_types` (
  `id_armor_type` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(24) NOT NULL,
  PRIMARY KEY (`id_armor_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `armors_types`
--

LOCK TABLES `armors_types` WRITE;
/*!40000 ALTER TABLE `armors_types` DISABLE KEYS */;
INSERT INTO `armors_types` VALUES (1,'Ligera'),(2,'Mediana'),(3,'Pesada');
/*!40000 ALTER TABLE `armors_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `char_item`
--

DROP TABLE IF EXISTS `char_item`;
/*!50001 DROP VIEW IF EXISTS `char_item`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `char_item` (
  `id_character` tinyint NOT NULL,
  `name` tinyint NOT NULL,
  `id_item` tinyint NOT NULL,
  `item` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `char_names`
--

DROP TABLE IF EXISTS `char_names`;
/*!50001 DROP VIEW IF EXISTS `char_names`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `char_names` (
  `id_character` tinyint NOT NULL,
  `name` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters` (
  `id_character` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `age` int(11) NOT NULL,
  `birthdate` date DEFAULT NULL,
  `hp` int(11) NOT NULL,
  `gender` char(1) NOT NULL,
  `style` char(1) NOT NULL,
  `mana` int(11) NOT NULL,
  `class` char(2) NOT NULL,
  `race` char(2) NOT NULL,
  `xp` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `height` float NOT NULL,
  PRIMARY KEY (`id_character`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (1,'Jacinto',12309,NULL,999,'F','R',100000,'Mg','Sg',1000000,0,2.1),(2,'Alejandro',2,NULL,0,'M','M',1,'De','Nd',100,2,1.2),(3,'Paca',43,NULL,100,'F','G',0,'Wa','Lo',500,70,4.52),(4,'Maricarmen',2,NULL,100,'N','H',100,'T','B',200,100,0.25),(5,'Bad Bunny',26,NULL,50,'M','R',200,'PA','H',260,26,1.8);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters_armors`
--

DROP TABLE IF EXISTS `characters_armors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters_armors` (
  `id_character_armor` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_character` int(10) unsigned NOT NULL,
  `id_armor` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_character_armor`),
  KEY `id_character` (`id_character`),
  KEY `id_armor` (`id_armor`),
  CONSTRAINT `characters_armors_ibfk_1` FOREIGN KEY (`id_character`) REFERENCES `characters` (`id_character`),
  CONSTRAINT `characters_armors_ibfk_2` FOREIGN KEY (`id_armor`) REFERENCES `armors` (`id_armor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters_armors`
--

LOCK TABLES `characters_armors` WRITE;
/*!40000 ALTER TABLE `characters_armors` DISABLE KEYS */;
/*!40000 ALTER TABLE `characters_armors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters_items`
--

DROP TABLE IF EXISTS `characters_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters_items` (
  `id_character_item` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_character` int(10) unsigned NOT NULL,
  `id_item` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_character_item`),
  KEY `id_character` (`id_character`),
  KEY `id_item` (`id_item`),
  CONSTRAINT `characters_items_ibfk_1` FOREIGN KEY (`id_character`) REFERENCES `characters` (`id_character`),
  CONSTRAINT `characters_items_ibfk_2` FOREIGN KEY (`id_item`) REFERENCES `items` (`id_item`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters_items`
--

LOCK TABLES `characters_items` WRITE;
/*!40000 ALTER TABLE `characters_items` DISABLE KEYS */;
INSERT INTO `characters_items` VALUES (1,1,1),(2,1,3),(3,1,4),(4,2,1),(5,3,2),(6,1,1);
/*!40000 ALTER TABLE `characters_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters_weapons`
--

DROP TABLE IF EXISTS `characters_weapons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters_weapons` (
  `id_character_weapon` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_character` int(10) unsigned NOT NULL,
  `id_weapon` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_character_weapon`),
  KEY `id_character` (`id_character`),
  KEY `id_weapon` (`id_weapon`),
  CONSTRAINT `characters_weapons_ibfk_1` FOREIGN KEY (`id_character`) REFERENCES `characters` (`id_character`),
  CONSTRAINT `characters_weapons_ibfk_2` FOREIGN KEY (`id_weapon`) REFERENCES `weapons` (`id_weapon`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters_weapons`
--

LOCK TABLES `characters_weapons` WRITE;
/*!40000 ALTER TABLE `characters_weapons` DISABLE KEYS */;
INSERT INTO `characters_weapons` VALUES (1,1,3),(2,2,2),(3,3,4),(4,4,3);
/*!40000 ALTER TABLE `characters_weapons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items` (
  `id_item` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item` varchar(24) NOT NULL,
  `cost` int(11) NOT NULL,
  `consumable` tinyint(1) NOT NULL,
  `tradeable` tinyint(1) NOT NULL,
  `weight` int(11) NOT NULL,
  `image` varchar(32) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `id_item_type` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_item`),
  KEY `id_item_type` (`id_item_type`),
  CONSTRAINT `items_ibfk_1` FOREIGN KEY (`id_item_type`) REFERENCES `items_types` (`id_item_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'Poción de vida',25,1,1,0,'health_potion.png','Una poción que recupera vida',3),(2,'Gafas de sol',100,0,1,0,'sunglasses.png','Gafas de sol facheritas',2),(3,'Guijarro',0,0,0,0,'small_stone.png','Pequeña piedra que encuentras en el suelo y lo pudes tirar a alguien supongo',1),(4,'Agua de río',1000,1,0,1,'river_water.png','Agua del río con propiedades medicinales que recupera energía de vitalidad',4),(5,'Manzana',3,1,1,0,'apple.png','Manzana Pro',3),(6,'Llave',25,0,0,0,'key.png','Llve que abre la puerta del destino',4),(7,'Gran Anillo',300,0,1,0,'big_ring.png','Gran anillo de las profundidades',2),(8,'Papel',2,0,1,0,'paper.png','Papel pequeño en blanco',3);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items_types`
--

DROP TABLE IF EXISTS `items_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `items_types` (
  `id_item_type` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(16) NOT NULL,
  PRIMARY KEY (`id_item_type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items_types`
--

LOCK TABLES `items_types` WRITE;
/*!40000 ALTER TABLE `items_types` DISABLE KEYS */;
INSERT INTO `items_types` VALUES (1,'Otros'),(2,'Equipable'),(3,'Consumible'),(4,'Clave');
/*!40000 ALTER TABLE `items_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `skills`
--

DROP TABLE IF EXISTS `skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `skills` (
  `id_skill` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `skill` varchar(24) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id_skill`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `skills`
--

LOCK TABLES `skills` WRITE;
/*!40000 ALTER TABLE `skills` DISABLE KEYS */;
/*!40000 ALTER TABLE `skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stats` (
  `id_stat` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `intel` int(11) DEFAULT NULL,
  `strength` int(11) DEFAULT NULL,
  `speed` int(11) DEFAULT NULL,
  `charisma` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `id_character` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_stat`),
  KEY `id_character` (`id_character`),
  CONSTRAINT `stats_ibfk_1` FOREIGN KEY (`id_character`) REFERENCES `characters` (`id_character`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stats`
--

LOCK TABLES `stats` WRITE;
/*!40000 ALTER TABLE `stats` DISABLE KEYS */;
INSERT INTO `stats` VALUES (1,33,22,NULL,333,33,1),(2,1,1,NULL,1,1,2),(3,75,2000,NULL,60,70,3),(4,9999,20,NULL,1,10,4);
/*!40000 ALTER TABLE `stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id_user` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(24) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'reshulon17'),(2,'alejandro18'),(3,'badbunny2021');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `v_items_types`
--

DROP TABLE IF EXISTS `v_items_types`;
/*!50001 DROP VIEW IF EXISTS `v_items_types`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `v_items_types` (
  `id_item` tinyint NOT NULL,
  `item` tinyint NOT NULL,
  `type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `weapons`
--

DROP TABLE IF EXISTS `weapons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weapons` (
  `id_weapon` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `weapon` varchar(16) NOT NULL,
  `damage` int(11) NOT NULL,
  `quality` int(11) NOT NULL,
  `rarity` int(11) NOT NULL,
  `weight` int(11) NOT NULL,
  `durability` int(11) NOT NULL,
  `range` int(11) NOT NULL,
  `id_weapon_type` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_weapon`),
  KEY `id_weapon_type` (`id_weapon_type`),
  CONSTRAINT `weapons_ibfk_1` FOREIGN KEY (`id_weapon_type`) REFERENCES `weapons_types` (`id_weapon_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weapons`
--

LOCK TABLES `weapons` WRITE;
/*!40000 ALTER TABLE `weapons` DISABLE KEYS */;
INSERT INTO `weapons` VALUES (1,'Espada larga',200,30,10,10,500,100,1),(2,'Espada corta',100,5,5,10,300,50,1),(3,'Lanza de Midgar',400,100,50,100,1000,400,2),(4,'Lanza de Shojin',500,70,20,50,900,300,2),(5,'Cuchilla Negra',250,50,700,30,1200,250,3);
/*!40000 ALTER TABLE `weapons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weapons_types`
--

DROP TABLE IF EXISTS `weapons_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weapons_types` (
  `id_weapon_type` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(24) NOT NULL,
  PRIMARY KEY (`id_weapon_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weapons_types`
--

LOCK TABLES `weapons_types` WRITE;
/*!40000 ALTER TABLE `weapons_types` DISABLE KEYS */;
INSERT INTO `weapons_types` VALUES (1,'Espada'),(2,'Lanza'),(3,'Hacha');
/*!40000 ALTER TABLE `weapons_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `char_item`
--

/*!50001 DROP TABLE IF EXISTS `char_item`*/;
/*!50001 DROP VIEW IF EXISTS `char_item`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`enti`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `char_item` AS select `characters`.`id_character` AS `id_character`,`characters`.`name` AS `name`,`items`.`id_item` AS `id_item`,`items`.`item` AS `item` from ((`characters` left join `characters_items` on(`characters`.`id_character` = `characters_items`.`id_character`)) left join `items` on(`characters_items`.`id_item` = `items`.`id_item`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `char_names`
--

/*!50001 DROP TABLE IF EXISTS `char_names`*/;
/*!50001 DROP VIEW IF EXISTS `char_names`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`enti`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `char_names` AS select `characters`.`id_character` AS `id_character`,`characters`.`name` AS `name` from `characters` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_items_types`
--

/*!50001 DROP TABLE IF EXISTS `v_items_types`*/;
/*!50001 DROP VIEW IF EXISTS `v_items_types`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`enti`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_items_types` AS select `items`.`id_item` AS `id_item`,`items`.`item` AS `item`,`items_types`.`type` AS `type` from (`items` left join `items_types` on(`items`.`id_item_type` = `items_types`.`id_item_type`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-09 14:22:29
